import serial
from PIL import Image
from io import BytesIO
import base64
import subprocess
import os
import time

ser = serial.Serial('COM6', 9600, timeout=1)
image_directory = "Images"  # Replace with the name of your image directory

correct_uid = "c2de642f"  # Replace with the UID of your RFID tag

while True:
    uid = ser.readline().decode().strip()
    if uid == correct_uid:
        print("Correct UID detected. Displaying image.")

        # Construct the path to the image file based on the UID
        image_path = os.path.join(image_directory, f"{uid}.jpg")

        # Check if the image file exists
        if os.path.exists(image_path):
            # Load the image using PIL
            image = Image.open(image_path)

            # Display the image using the default image viewer
            image.show()

            # You can customize this part to use a specific image viewer program
            # For example, on Windows, you can use the following command:
            # subprocess.run(["start", "mspaint", image_path])
        else:
            print(f"Image not found for UID: {uid}")

    # Wait for a moment to avoid processing multiple readings quickly
    ser.flushInput()
    ser.flushOutput()
    ser.flush()
    ser.reset_input_buffer()
    ser.reset_output_buffer()
    ser.readline()  # Read and discard any remaining data in the serial buffer
    ser.flushInput()
    ser.flushOutput()
    ser.flush()
    time.sleep(1)
